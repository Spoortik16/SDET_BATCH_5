package com.devlabs.lab7;

public class ConcatenadeTwoStrings {

	public static void main(String[] args) {
		
		String a = "Pavan";
		String b = a.concat("Kumar");
		
		System.out.println("Print the string : " +b);
		
		

	}

}
