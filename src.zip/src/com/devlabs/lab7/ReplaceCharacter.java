package com.devlabs.lab7;

public class ReplaceCharacter {

	public static void main(String[] args) {
		
		String B = "Pan Pun Prank Pit Pat";
		
		String X = B.replace('P','F');
        System.out.println("Replace String with F: "+X);

	}

}
