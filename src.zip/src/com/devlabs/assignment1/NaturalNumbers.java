package com.devlabs.assignment1;

public class NaturalNumbers {

    public static void main(String[] args) {
          // TODO Auto-generated method stub

          int count,total=0;
          for(count=1;count<=20;count++) {
                 total=total+count;
          }
          System.out.println("sum of first 20 natural numbers:" + total);
    }

}


