package com.devlabs.assignment1;

import java.util.Scanner;

public class AreaOfTriangle {

       public static void main(String[] args) {
             // TODO Auto-generated method stub

             Scanner scanner = new Scanner(System.in);
                System.out.println("Enter the base  :");
             double base =scanner.nextDouble();
             System.out.println("Enter the height :");
             double height =scanner.nextDouble();
             double area =(base*height)/2;
             System.out.println("Area of triangle is:"+area);
             scan.close(); 
             
       }

}

