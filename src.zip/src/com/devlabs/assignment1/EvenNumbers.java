package com.devlabs.assignment1;

public class EvenNumbers {

    public static void main(String[] args) {
          // TODO Auto-generated method stub

          int n=50;
          System.out.println("Even number till " +n+ " are :" );
                       for(int i=1; i<=n;i++) {
                              if(i%2==0)
                              {
                                    System.out.println(i +"");
                              }
                 }
    }
}

