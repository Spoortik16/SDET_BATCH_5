package com.devlabs.lab5;

//Example 3: do while


public class DoWhileDemo {
//printout numbers from 20 to 1 in reverse order
  public static void main(String[] args) {
      int i=20;
      do{
          System.out.print(" "+i);
          i--;
          
      }while(i>0);
      
      
  }
}
