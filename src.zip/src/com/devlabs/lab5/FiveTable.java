package com.devlabs.lab5;

public class FiveTable {

    public static void main(String[] args) 
    {
        int result;
        for (int i = 1; i <= 10; i++) 
        {
            result = 5*i;
            System.out.println(result);
        }

    }

}

