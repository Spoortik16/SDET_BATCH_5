package com.devlabs.lab3;

public interface MathsInterface
{
    public void add(int a, int b);
    public void subtract(int a, int b);
    public void multiply(int a, int b);
    public void divide(int a, int b);

}
