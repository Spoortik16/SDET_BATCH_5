package com.devlabs.lab1;

public class AreaPerimeterOfRectangle {

	public static void main(String[] args) {
		
		int lenght=10, width=8;
		
		double area;
		double perimeter;
		
		area = lenght*width;
		System.out.println("The area is:" + area);
		
		perimeter = 2 * (lenght + width);
		System.out.println("The perimeter is:" + perimeter);
		

	}

}
