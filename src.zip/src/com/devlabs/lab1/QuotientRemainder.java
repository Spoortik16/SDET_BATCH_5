package com.devlabs.lab1;

public class QuotientRemainder {

	public static void main(String[] args) {
		int dividend=556, divisor=9;
		
		int quotient = dividend / divisor;
		int remainder = dividend % divisor;
		
		System.out.println("quotient is = :  " + quotient);
		
	    System.out.println("remainder is = : " + remainder);
		

	}

}
