//Datatypes  Example

package com.devlabs.lab1;

public class DataTypesExample {

    int item_id, quantity;
    //int quantity; //default value = 0
    
    double price = 0,discount,total_amt=0; 
    
    boolean memberCheck; //false
    
    String comments = "Welcome again!"; //null
    
    char c = '&'; //single quotes
    
}
